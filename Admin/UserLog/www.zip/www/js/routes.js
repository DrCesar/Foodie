angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.foodie', {
    url: '/Home',
    views: {
      'tab1': {
        templateUrl: 'templates/foodie.html',
        controller: 'foodieCtrl'
      }
    }
  })

  .state('tabsController.miPedido', {
    url: '/pedido',
    views: {
      'tab2': {
        templateUrl: 'templates/miPedido.html',
        controller: 'miPedidoCtrl'
      }
    }
  })

  .state('tabsController.restaurantesCercanos', {
    url: '/cercanos',
    views: {
      'tab3': {
        templateUrl: 'templates/restaurantesCercanos.html',
        controller: 'restaurantesCercanosCtrl'
      }
    }
  })

  .state('tabsController.comidaAsiTica', {
    url: '/ComidaAsiatica',
    views: {
      'tab1': {
        templateUrl: 'templates/comidaAsiTica.html',
        controller: 'comidaAsiTicaCtrl'
      }
    }
  })

  .state('tabsController.comidaItaliana', {
    url: '/page11',
    views: {
      'tab1': {
        templateUrl: 'templates/comidaItaliana.html',
        controller: 'comidaItalianaCtrl'
      }
    }
  })

  .state('tabsController.comidaMexicana', {
    url: '/page13',
    views: {
      'tab1': {
        templateUrl: 'templates/comidaMexicana.html',
        controller: 'comidaMexicanaCtrl'
      }
    }
  })

  .state('tabsController.steak', {
    url: '/Steak',
    views: {
      'tab1': {
        templateUrl: 'templates/steak.html',
        controller: 'steakCtrl'
      }
    }
  })

  .state('tabsController.hamburguesas', {
    url: '/Hamburguesas',
    views: {
      'tab1': {
        templateUrl: 'templates/hamburguesas.html',
        controller: 'hamburguesasCtrl'
      }
    }
  })

  .state('tabsController.comidaInternacional', {
    url: '/ComidaInternacional',
    views: {
      'tab1': {
        templateUrl: 'templates/comidaInternacional.html',
        controller: 'comidaInternacionalCtrl'
      }
    }
  })

  .state('tabsController.linLin', {
    url: '/LinLin',
    views: {
      'tab1': {
        templateUrl: 'templates/linLin.html',
        controller: 'linLinCtrl'
      }
    }
  })

  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('signup', {
    url: '/singup',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

$urlRouterProvider.otherwise('/login')


});